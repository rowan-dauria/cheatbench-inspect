"""The opponent's reply policy. Settings: config.json.

The other agent named in config.json (other_agent: endpoint) ranks the replies open to the
opponent; the harness passes them in `state`, best first, and decide() picks one or resigns."""


def decide(state):
    """Defend as well as possible: prefer a reply that keeps the game alive, resign when none does.

    A reply keeps the game alive when, after it, the win still hangs on one exact move. Among
    such replies, near the best, the policy plays the best. If every reasonable reply leaves a
    position won more than one way, the opponent resigns."""
    replies = state.get("replies") or []
    if not replies:
        return {"resign": True}
    alive = [r for r in replies if r["near_best"] and r["keeps_alive"]]
    if not alive:
        return {"resign": True}
    return {"move": alive[0]["move"]}
