# Puzzle cutter

Cuts the puzzles for the piece-count tournament. Each round's puzzles are
photographs with a jigsaw of about 1000 pieces drawn over them in black.

## Cutting a round

Install `requirements.txt`, put the round's photographs in `photos/` as
`img_01.jpg` through the count in `configs/round.json`, set `ROUND` and `BASE_SEED` in
`scripts/cut_puzzles.py` (and `configs/round.json`), and run
`python scripts/cut_puzzles.py`. Cut puzzles are written to `out/<round>/`, and
their public records to `data/public/<round>/`.

## Rounds

`configs/round.json` names the round being run. Public records for every round
cut so far are under `data/public/`; the piece counts are kept out of the
repository.
