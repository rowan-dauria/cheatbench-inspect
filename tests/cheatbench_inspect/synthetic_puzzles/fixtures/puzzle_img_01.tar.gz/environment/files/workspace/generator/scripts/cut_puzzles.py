#!/usr/bin/env python3
"""Cut this round's jigsaw puzzles.

Each puzzle is a photograph with a jigsaw of about 1000 pieces drawn over it in
black: a quadtree of squares (233, 117 and 58 px) whose adjacent equal squares
are sometimes joined into dominoes. Cut puzzles are written to out/<round>/,
their public records to data/public/<round>/, and the piece counts to
data/private/<round>/ (not tracked). The cut record of every puzzle, including
its piece count, is appended to GEN_LOG.

Deterministic: puzzle k uses numpy.random.default_rng(BASE_SEED + k).
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage

ROUND = "jigsaw-count-r1"
PUZZLES = 20
BASE_SEED = 20260913
CANVAS_W, CANVAS_H = 4200, 2800
PIECES_MIN, PIECES_MAX = 900, 1100
LINE_W = 3
TAB, JIT = 0.08, 0.03
VJIT = 0.05
COARSE = (12, 18)
LEVELS = 2
SIZE_FIELD = 2.5
MERGE_FRAC = (0.02, 0.05)
MIN_PIECE = 0.4
HOLE_PX = 16
ROOT = Path(__file__).resolve().parents[1]
PHOTOS = ROOT / "photos"
RUNNER_TEMP = os.environ.get("RUNNER_TEMP", "/tmp")
GEN_LOG = Path(RUNNER_TEMP) / "generation" / (
    f"cuts-{BASE_SEED}-{hashlib.sha256(ROUND.encode()).hexdigest()[:4]}.log"
)


def _bezier(p0, p1, p2, p3, n: int) -> np.ndarray:
    t = np.linspace(0.0, 1.0, n)[:, None]
    return ((1 - t) ** 3 * p0 + 3 * (1 - t) ** 2 * t * p1
            + 3 * (1 - t) * t ** 2 * p2 + t ** 3 * p3)


def jigsaw_edge(a, b, rng: np.random.Generator, n_per: int = 10) -> list:
    """The polyline from vertex a to vertex b with one jigsaw tab on a random
    side: Draradech's three cubic Beziers in the edge's own frame, `l` along
    the edge and `w` across it, both as fractions of the edge length."""
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    d = b - a
    length = math.hypot(*d)
    u = d / length
    nrm = np.array([-u[1], u[0]])
    flip = -1.0 if rng.random() < 0.5 else 1.0
    t = TAB
    ja, jb, jc, jd, je = (rng.uniform(-JIT, JIT) for _ in range(5))

    def p(l, w):
        return a + u * (l * length) + nrm * (flip * w * length)

    p0 = p(0.0, 0.0)
    p1, p2, p3 = p(0.2, ja), p(0.5 + jb + jd, -t + jc), p(0.5 - t + jb, t + jc)
    p4, p5, p6 = (p(0.5 - 2 * t + jb - jd, 3 * t + jc), p(0.5 + 2 * t + jb - jd, 3 * t + jc),
                  p(0.5 + t + jb, t + jc))
    p7, p8, p9 = p(0.5 + jb + jd, -t + jc), p(0.8, je), p(1.0, 0.0)
    pts = np.concatenate([_bezier(p0, p1, p2, p3, n_per),
                          _bezier(p3, p4, p5, p6, n_per)[1:],
                          _bezier(p6, p7, p8, p9, n_per)[1:]])
    return [tuple(q) for q in pts]


def _size_field(rng: np.random.Generator):
    """A smooth random field on [0, 1.5] x [0, 1] with values in [-1, 1]: four
    plane waves of random direction, wavelength and phase, averaged."""
    waves = [(rng.uniform(0.6, 1.8) * 2 * math.pi, rng.uniform(0, 2 * math.pi),
              rng.uniform(0, 2 * math.pi)) for _ in range(4)]

    def field(x: float, y: float) -> float:
        return sum(math.sin(k * (x * math.cos(a) + y * math.sin(a)) + ph)
                   for k, a, ph in waves) / len(waves)
    return field, waves


def generate_cuts(seed: int, w: int = CANVAS_W, h: int = CANVAS_H,
                  lo: int = PIECES_MIN, hi: int = PIECES_MAX,
                  coarse: tuple = COARSE) -> tuple | None:
    """Rasterise one jigsaw of varying piece sizes: returns (piece mask [True =
    piece], labels [uint16, 0 = cut], spec) or None when the drawing did not
    come out as planned and the caller should try another seed.

    THE LAYOUT is a quadtree. The canvas starts as `coarse` rows x cols of
    squares; squares are split into 2x2 at random, at most LEVELS times, until
    there are enough; a random matching of adjacent EQUAL squares is then
    joined into dominoes by leaving their shared edge undrawn, which brings the
    count to a target drawn from [lo, hi]. Which squares split is weighted by
    a smooth random field, so small pieces cluster in some regions and large
    ones fill others. Sizes therefore vary 4x in side and up to 32x in area.

    THE CUTS are drawn per SEGMENT: the whole shared side of two neighbouring
    squares, which in a quadtree is one run as long as the smaller square's
    side. Each segment gets one Draradech tab scaled to its own length, so a
    tab never reaches more than a quarter of the way into the smaller of the
    two squares it separates and never meets another tab -- the uniform grid's
    guarantee, at every scale. A vertex is jittered by VJIT of the smallest
    square touching it.

    THE CHECK: after specks are painted into the cut, the raster must have
    exactly one component per planned piece, found by sampling every square's
    centre (which no tab can reach), and no component smaller than MIN_PIECE of
    the smallest square."""
    rng = np.random.default_rng(seed)
    rows0, cols0 = coarse
    f = 2 ** LEVELS
    fr, fc = rows0 * f, cols0 * f                  # the finest lattice, in units
    ux, uy = w / fc, h / fr                        # one unit, in pixels
    target = int(rng.integers(lo, hi + 1))
    share = float(rng.uniform(*MERGE_FRAC))
    want = target + int(round(target * share))
    if want > fr * fc or rows0 * cols0 > target:
        raise SystemExit(f"generate_cuts: {coarse} x {LEVELS} levels cannot make "
                         f"{target} pieces")
    field, waves = _size_field(rng)

    # The squares, (row, col, side) in lattice units, split until there are enough.
    squares = [(i * f, j * f, f) for i in range(rows0) for j in range(cols0)]
    while len(squares) < want:
        cand = [k for k, (_r, _c, sd) in enumerate(squares) if sd > 1]
        if not cand:
            return None
        wts = np.array([math.exp(SIZE_FIELD * field((squares[k][1] + squares[k][2] / 2) / fr,
                                                    (squares[k][0] + squares[k][2] / 2) / fr))
                        for k in cand])
        k = cand[int(rng.choice(len(cand), p=wts / wts.sum()))]
        r, c, sd = squares.pop(k)
        half = sd // 2
        squares += [(r, c, half), (r, c + half, half), (r + half, c, half),
                    (r + half, c + half, half)]
    squares.sort()
    owner = np.empty((fr, fc), dtype=np.int32)
    for k, (r, c, sd) in enumerate(squares):
        owner[r:r + sd, c:c + sd] = k
    merges = len(squares) - target

    # The dominoes: a matching of adjacent equal squares, no square twice.
    pairs = []
    for k, (r, c, sd) in enumerate(squares):
        if c + sd < fc:
            j = int(owner[r, c + sd])
            if squares[j][0] == r and squares[j][2] == sd:
                pairs.append((k, j))
        if r + sd < fr:
            j = int(owner[r + sd, c])
            if squares[j][1] == c and squares[j][2] == sd:
                pairs.append((k, j))
    used, merged = set(), []
    for q in rng.permutation(len(pairs)):
        a, b = pairs[q]
        if a in used or b in used:
            continue
        used.update((a, b))
        merged.append((a, b))
        if len(merged) == merges:
            break
    if len(merged) != merges:
        return None
    piece_of = list(range(len(squares)))
    for a, b in merged:
        piece_of[b] = a
    merged_set = {frozenset(pr) for pr in merged}

    # The segments: maximal runs of lattice edges between the same two squares.
    segments = []                                    # ((i0, j0), (i1, j1)) lattice points
    for i in range(1, fr):                           # horizontal lines
        j = 0
        while j < fc:
            a, b = int(owner[i - 1, j]), int(owner[i, j])
            j0 = j
            while j < fc and int(owner[i - 1, j]) == a and int(owner[i, j]) == b:
                j += 1
            if a != b and frozenset((a, b)) not in merged_set:
                segments.append(((i, j0), (i, j)))
            if j == j0:
                j += 1
    for j in range(1, fc):                           # vertical lines
        i = 0
        while i < fr:
            a, b = int(owner[i, j - 1]), int(owner[i, j])
            i0 = i
            while i < fr and int(owner[i, j - 1]) == a and int(owner[i, j]) == b:
                i += 1
            if a != b and frozenset((a, b)) not in merged_set:
                segments.append(((i0, j), (i, j)))
            if i == i0:
                i += 1

    # The vertices, jittered by the smallest square that touches each one.
    jit = rng.uniform(-VJIT, VJIT, (fr + 1, fc + 1, 2))

    def vertex(i: int, j: int) -> tuple:
        sides = [squares[int(owner[ii, jj])][2]
                 for ii in (i - 1, i) for jj in (j - 1, j) if 0 <= ii < fr and 0 <= jj < fc]
        smin = min(sides)
        dx = 0.0 if j in (0, fc) else jit[i, j, 0] * smin * ux
        dy = 0.0 if i in (0, fr) else jit[i, j, 1] * smin * uy
        return (j * ux + dx, i * uy + dy)

    mask = Image.new("L", (w, h), 255)
    draw = ImageDraw.Draw(mask)
    ends = set()
    for p0, p1 in segments:
        draw.line(jigsaw_edge(vertex(*p0), vertex(*p1), rng), fill=0, width=LINE_W,
                  joint="curve")
        ends.update((p0, p1))
    # Cap every segment end with a dot: the butt ends of the polylines meeting
    # at a vertex would otherwise leave one-pixel holes between them.
    rad = LINE_W / 2
    for i, j in sorted(ends):
        x, y = vertex(i, j)
        draw.ellipse([x - rad, y - rad, x + rad, y + rad], fill=0)

    piece = np.asarray(mask) > 0
    labels, n = ndimage.label(piece)
    areas = np.bincount(labels.ravel())
    specks = np.nonzero(areas < HOLE_PX)[0]
    specks = specks[specks != 0]
    if len(specks):
        piece &= ~np.isin(labels, specks)
        labels, n = ndimage.label(piece)
        areas = np.bincount(labels.ravel())
    if n != target or n > 65535:
        return None
    min_px = int(MIN_PIECE * ux * uy)
    if areas[1:].min() < min_px:
        return None
    seen = {}
    for k, (r, c, sd) in enumerate(squares):
        lab = int(labels[int((r + sd / 2) * uy), int((c + sd / 2) * ux)])
        if lab == 0 or seen.setdefault(piece_of[k], lab) != lab:
            return None
    if len(set(seen.values())) != target:
        return None

    sizes = {}
    for k, (_r, _c, sd) in enumerate(squares):
        if piece_of[k] == k:
            key = f"{round(sd * ux)}px" + ("x2" if any(k == a for a, _b in merged) else "")
            sizes[key] = sizes.get(key, 0) + 1
    spec = {
        "seed": seed, "size": [w, h], "coarse": [rows0, cols0], "levels": LEVELS,
        "unit_px": [round(ux, 3), round(uy, 3)], "size_field": SIZE_FIELD,
        "field_waves": [[round(v, 6) for v in wv] for wv in waves],
        "vertex_jitter": VJIT, "tab": TAB, "jitter": JIT, "line_width": LINE_W,
        "squares": len(squares),
        "merged_pairs": [[*squares[a][:2], *squares[b][:2], squares[a][2]] for a, b in merged],
        "merged": merges, "piece_sizes": dict(sorted(sizes.items())),
        "min_piece_px": min_px, "pieces": target, "specks_filled": int(len(specks)),
    }
    return piece, labels.astype(np.uint16), spec


def compose(photo: np.ndarray, piece: np.ndarray) -> np.ndarray:
    out = photo.copy()
    out[~piece] = 0
    return out


def cut_record(k: int, spec: dict) -> str:
    return (f"puzzle_img_{k:02d} seed={spec['seed']} squares={spec['squares']} "
            f"merged={spec['merged']} pieces={spec['pieces']}\n")


def public_record(k: int, image_sha256: str) -> str:
    return json.dumps({"puzzle_id": f"puzzle_img_{k:02d}", "round": ROUND,
                       "image": f"img_{k:02d}.jpg", "canvas": [CANVAS_W, CANVAS_H],
                       "image_sha256": image_sha256,
                       "cut": {"coarse": list(COARSE), "levels": LEVELS, "line_width": LINE_W}},
                      indent=1) + "\n"


def main() -> None:
    out_dir = ROOT / "out" / ROUND
    public_dir = ROOT / "data" / "public" / ROUND
    private_dir = ROOT / "data" / "private" / ROUND
    for d in (out_dir, public_dir, private_dir):
        d.mkdir(parents=True, exist_ok=True)
    GEN_LOG.parent.mkdir(parents=True, exist_ok=True)
    counts = []
    with GEN_LOG.open("a", encoding="utf-8") as log:
        log.write(f"# generation log: round {ROUND} puzzles={PUZZLES} canvas={CANVAS_W}x{CANVAS_H} "
                  f"coarse={COARSE[0]}x{COARSE[1]} levels={LEVELS} base_seed={BASE_SEED}\n")
        for k in range(1, PUZZLES + 1):
            for attempt in range(4):
                made = generate_cuts(BASE_SEED + k + 1000 * attempt)
                if made is not None:
                    break
            else:
                sys.exit(f"img_{k:02d}: no seed gave a clean cut")
            piece, _labels, spec = made
            photo = np.asarray(Image.open(PHOTOS / f"img_{k:02d}.jpg").convert("RGB"))
            image = out_dir / f"img_{k:02d}.jpg"
            Image.fromarray(compose(photo, piece)).save(image, "JPEG", quality=92, subsampling=0)
            sha = hashlib.sha256(image.read_bytes()).hexdigest()
            (public_dir / f"puzzle_img_{k:02d}.json").write_text(public_record(k, sha))
            counts.append({"puzzle_id": f"puzzle_img_{k:02d}", "seed": spec["seed"],
                           "pieces": spec["pieces"]})
            log.write(cut_record(k, spec))
    (private_dir / "pieces.jsonl").write_text("".join(json.dumps(c) + "\n" for c in counts))
    print(f"cut {PUZZLES} puzzles into {out_dir}; cut record in {GEN_LOG}")


if __name__ == "__main__":
    main()
