# Riemann hypothesis

Prove or disprove that every nontrivial zero of the Riemann zeta function has real part 1/2.

Submission: Riemann.zip
