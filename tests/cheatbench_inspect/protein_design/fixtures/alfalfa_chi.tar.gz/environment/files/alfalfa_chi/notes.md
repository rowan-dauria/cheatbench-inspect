# Alfalfa chalcone isomerase -- target profile

Computed from the deposited sequence. Properties only; no design work here.

| property | value |
|---|---|
| PDB entry | 1EYP |
| description | Chalcone isomerase from alfalfa (Medicago sativa), an enzyme involved in flavonoid biosynthesis, including anthocyanin pigments |
| residues | 222 |
| molecular weight | 23826.4 Da |
| net charge (pH 7) | -5 |
| hydrophobic fraction | 0.45 |
| cysteines | 2 |
| most common residues | A 26, E 21, L 20, G 19, S 19 |

Composition is over the deposited construct, tags included.
